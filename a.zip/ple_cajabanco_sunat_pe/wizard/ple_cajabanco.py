# -*- encoding: utf-8 -*-
from odoo.osv import osv
import base64
from odoo import models, fields, api, exceptions, _
import importlib

import unidecode


class ple_cajabanco_wizard(osv.TransientModel):
    _name = 'ple.cajabanco.wizard'

    company_id = fields.Many2one('res.company', string=u'Compañía', required=True,
                                 default=lambda self: self.env.user.company_id)
    period = fields.Many2one('account.period', 'Periodo')
    tipo = fields.Selection([('caja', 'Caja'), ('banco', 'Banco')], 'Tipo', required=True)

    @api.multi
    def do_rebuild(self):
        direccion = self.env['main.parameter'].search([])[0].dir_create_file
        if not direccion:
            raise osv.except_osv('Alerta!', 'No esta configurado la dirección de Directorio en Parametros')
        otro_periodo = self.period
        if self.period.code.split('/')[0] == '01':
            otro_periodo = self.env['account.period'].search(
                [('company_id', '=', self.company_id.id), ('code', '=', '00/' + self.period.code.split('/')[1])])[0] if \
                self.period.code.split('/')[0] == '01' else self.period
        elif self.period.code.split('/')[0] == '12':
            otro_periodo = (self.env['account.period'].search(
                [('company_id', '=', self.company_id.id), ('code', '=', '13/' + self.period.code.split('/')[1])])[
                                0] if len(self.env['account.period'].search(
                [('code', '=', '13/' + self.period.code.split('/')[1])])) > 0 else self.period) if \
                self.period.code.split('/')[0] == '12' else self.period

        if self.tipo == 'caja':
            query = """		
            COPY (
                SELECT substring(ap.code , 4, 4) || '""" + self.period.code.split('/')[0] + """' || '00'                     as campo1,
                    CASE
                       WHEN aj.register_sunat = '1' or aj.register_sunat = '2' THEN
                               substring(ap.code, 4, 5) || substring(ap.code, 0, 3) || aj.code || am.name
                       ELSE substring(ap.code, 4, 5) || substring(ap.code, 0, 3) || aj.code || am.name END
                                                                                                                              as campo2,
                    CASE
                       WHEN substring(ap.code, 0, 3)::text = '00'::text
                           THEN 'A' || am.id || LPAD((ROW_NUMBER() OVER ( PARTITION BY am.id ORDER BY am.id )::text), 2, '0')
                       ELSE 'M' || am.id || LPAD((ROW_NUMBER() OVER ( PARTITION BY am.id ORDER BY am.id )::text), 2,
                                                 '0') END                                                                     as campo3,
                    aa.code                                                                                                    AS campo4,
                    am.name                                                                                                    AS campo5,
                    ''::TEXT                                                                                                         AS campo6,
                    COALESCE(rc.name, (SELECT rc_1.name
                                      FROM res_company
                                               JOIN res_currency rc_1
                                                    ON rc_1.id = res_company.currency_id and res_company.id = am.company_id)) AS campo7,
            
                    CASE
                    WHEN itd_inv.code IS NULL THEN
                        coalesce(aji.pe_invoice_code,'00')
                    ELSE
                        coalesce(itd_inv.code,'00')
                    END                                                                                                    as campo8,
                    CASE
                       WHEN ai.type = 'out_invoice' or ai.type = 'out_refund' THEN
                           coalesce(split_part(ai.number, '-', 1)::TEXT,'-')
                       ELSE
                           coalesce(replace(replace(repeat('0', 4 - char_length("substring"(ai.reference::text, 0,
                                                               "position"(ai.reference::text, '-'::text)))) ||
                       "substring"(ai.reference::text, 0, "position"(ai.reference::text, '-'::text)), '/', '-'), '|',
                        '-'), '-')
                       END                                                                                                    as campo9,
                    CASE
                       WHEN ai.type = 'out_invoice' or ai.type = 'out_refund' THEN
                           coalesce(split_part(ai.number, '-', 2)::TEXT,'9999')
                       ELSE
                           coalesce("substring"(ai.reference::text,
                   "position"(ai.reference::text, '-'::text) + 1),'9999')
                       END                                                                                                    as campo10,
                    to_char(am.fecha_contable, 'DD/MM/YYYY')                                                                   as campo11,
                    to_char(aml.date_maturity, 'DD/MM/YYYY')                                                                   as campo12,
                    to_char(am.date, 'DD/MM/YYYY')                                                                             as campo13,
                    CASE WHEN aml.name != '' THEN
                        aml.name                                                                                                   
                    ELSE
                        am.name 
                    END 
                        as campo14,
                    ''                                                                                                         as campo15,
                    round(aml.debit,2)                                                                                                 AS campo16,
                    round(aml.credit,2)                                                                                                 AS campo17,
                    ''                                                                                                         as campo18,
                    am.ple_diariomayor                                                                                         as campo19,
                    '' as campo20
                  FROM account_move_line aml
                     JOIN account_move am ON am.id = aml.move_id
                     LEFT JOIN account_invoice ai on ai.id = aml.invoice_id
                     LEFT JOIN account_journal aji on aji.id = ai.journal_id
                     JOIN account_journal aj ON aj.id = am.journal_id
                     JOIN account_period ap ON ap.company_id = am.company_id and ap.date_start <= am.fecha_contable and
                                               ap.date_stop >= am.fecha_contable and ap.special = am.fecha_special
                     JOIN account_account aa ON aa.id = aml.account_id
            
                     JOIN account_account_type aat on aat.id = aa.user_type_id
                     LEFT JOIN einvoice_means_payment mp ON mp.id = am.means_payment_it
                     LEFT JOIN res_currency rc ON rc.id = aml.currency_id
                     LEFT JOIN res_partner rp ON rp.id = aml.partner_id
                     LEFT JOIN account_full_reconcile afr on afr.id = aml.full_reconcile_id
                     LEFT JOIN einvoice_catalog_01 itd ON itd.id = aml.type_document_it
                     LEFT JOIN einvoice_catalog_01 itd_inv ON itd_inv.id = ai.it_type_document
                     LEFT JOIN account_analytic_account aaa ON aaa.id = aml.analytic_account_id
            WHERE aat.type::text = 'liquidity'::text
                  and (aa.code ilike '101%%' or aa.code ilike '102%%' and aa.code ilike '103%%')
              --and ap.id = 18
                  and am.state != 'draft'
                  and ( ap.id = """ + str(self.period.id) + """ or ap.id = """ + str(
                otro_periodo.id) + """) and am.company_id = """ + str(self.company_id.id) + """) TO '""" + str(
                direccion + 'plecajabanco.csv') + """'
            with delimiter '|'
            """
            self.env.cr.execute(query)
            ruc = self.company_id.partner_id.doc_number
            mond = self.company_id.currency_id.name

            if not ruc:
                raise osv.except_osv('Alerta!', 'No esta configurado el RUC en la compañia')

            import sys
            importlib.reload(sys)

            txt_act = None
            corredor = 1
            exp_r = []
            for i in open(str(direccion + 'plecajabanco.csv'), 'r').readlines():
                tmp = i.split('|')
                if txt_act == None:
                    txt_act = tmp[1]
                elif txt_act != tmp[1]:
                    txt_act = tmp[1]
                    corredor = 1
                else:
                    corredor += 1
                tmp[1] = tmp[1] + str(corredor)
                exp_r.append('|'.join(tmp))

            exp = ("".join(exp_r)).replace('\\N', '').replace('|0.0|', '|0.00|')
            nombre_respec = 'LE' + ruc + self.period.code[3:7] + self.period.code[:2] + '00010100001' + (
                '1' if len(exp) > 0 else '0') + ('1' if mond == 'PEN' else '2') + '1.txt'

        else:
            query = """		
                        COPY (
                            SELECT substring(ap.code , 4, 4) || '""" + self.period.code.split('/')[0] + """' || '00'                     as campo1,
                                CASE
                                   WHEN aj.register_sunat = '1' or aj.register_sunat = '2' THEN
                                           substring(ap.code, 4, 5) || substring(ap.code, 0, 3) || aj.code || am.name
                                   ELSE substring(ap.code, 4, 5) || substring(ap.code, 0, 3) || aj.code || am.name END
                                                                        as campo2,
                                CASE
                                   WHEN substring(ap.code, 0, 3)::text = '00'::text
                                       THEN 'A' || am.id || LPAD((ROW_NUMBER() OVER ( PARTITION BY am.id ORDER BY am.id )::text), 2, '0')
                                   ELSE 'M' || am.id || LPAD((ROW_NUMBER() OVER ( PARTITION BY am.id ORDER BY am.id )::text), 2,
                                                             '0') END   as campo3,
                                aj.pe_bank_code                          AS campo4,
                                rpb.acc_number                           AS campo5,
                                to_char(am.fecha_contable, 'DD/MM/YYYY') as campo6,
                                CASE WHEN am.name ilike 'APERT%%' THEN
                                  '999'::TEXT
                                ELSE
                                  coalesce(mp.code,'003'::TEXT)
                                END AS campo7,
                                CASE WHEN aml.name != '' THEN
                                    aml.name                                                                                                   
                                ELSE
                                    am.name 
                                END                                 as campo8,
                                coalesce(rp.doc_type,'-')                             as campo9,
                                coalesce(rp.doc_number, '-')                            as campo10,
                                coalesce(rp.name,'varios')                                  as campo11,
                                CASE
                                   WHEN ai.type = 'out_invoice' or ai.type = 'out_refund' THEN
                                       coalesce(ai.number::text,'9999999')
                                   ELSE
                                       coalesce(ai.reference::text,'9999999')
                                   END                               as campo12,
                                round(aml.debit,2)                                AS campo13,
                                round(aml.credit,2)                               AS campo14,
                                am.ple_diariomayor                       as campo15,
                                aa.code                       as campo16,
                                '' as campo17
                                FROM account_move_line aml
                                 JOIN account_move am ON am.id = aml.move_id
                                 LEFT JOIN account_payment apa on apa.id = aml.payment_id
                                 LEFT JOIN account_invoice ai on ai.id = aml.invoice_id
                                 JOIN account_journal aj ON aj.id = am.journal_id
                                 LEFT JOIN res_partner_bank rpb on rpb.id = aj.bank_account_id
                                 JOIN account_period ap ON ap.company_id = am.company_id and ap.date_start <= am.fecha_contable and
                                                           ap.date_stop >= am.fecha_contable and ap.special = am.fecha_special
                                 JOIN account_account aa ON aa.id = aml.account_id
                        
                                 JOIN account_account_type aat on aat.id = aa.user_type_id
                                 LEFT JOIN einvoice_means_payment mp ON mp.id = am.means_payment_it
                                 LEFT JOIN res_currency rc ON rc.id = aml.currency_id
                                 LEFT JOIN res_partner rp ON rp.id = aml.partner_id
                                 LEFT JOIN account_full_reconcile afr on afr.id = aml.full_reconcile_id
                                 LEFT JOIN einvoice_catalog_01 itd ON itd.id = aml.type_document_it
                                 LEFT JOIN einvoice_catalog_01 itd_inv ON itd_inv.id = ai.it_type_document
                                 LEFT JOIN account_analytic_account aaa ON aaa.id = aml.analytic_account_id
                          WHERE aat.type::text = 'liquidity'::text
                            and (aa.code ilike '104%%')
                            --and aj.type = 'bank'
                            --and aj.id = 94
                            and am.state != 'draft'
                              and ( ap.id = """ + str(self.period.id) + """ or ap.id = """ + str(
                otro_periodo.id) + """) and am.company_id = """ + str(self.company_id.id) + """) TO '""" + str(
                direccion + 'plecajabanco.csv') + """'
                        with delimiter '|'
                        """
            self.env.cr.execute(query)
            ruc = self.company_id.partner_id.doc_number
            mond = self.company_id.currency_id.name

            if not ruc:
                raise osv.except_osv('Alerta!', 'No esta configurado el RUC en la compañia')

            import sys
            importlib.reload(sys)

            txt_act = None
            corredor = 1
            exp_r = []
            for i in open(str(direccion + 'plecajabanco.csv'), 'r').readlines():
                tmp = i.split('|')
                if txt_act == None:
                    txt_act = tmp[1]
                elif txt_act != tmp[1]:
                    txt_act = tmp[1]
                    corredor = 1
                else:
                    corredor += 1
                tmp[1] = tmp[1] + str(corredor)
                exp_r.append('|'.join(tmp))

            exp = ("".join(exp_r)).replace('\\N', '').replace('|0.0|', '|0.00|')

            nombre_respec = 'LE' + ruc + self.period.code[3:7] + self.period.code[:2] + '00010200001' + (
                '1' if len(exp) > 0 else '0') + ('1' if mond == 'PEN' else '2') + '1.txt'

        vals = {
            'output_name': nombre_respec,
            'output_file': base64.encodestring(("-- Sin Registros --" if exp == "" else exp).encode('utf-8')),
        }
        sfs_id = self.env['export.file.save'].create(vals)
        return {
            "type": "ir.actions.act_window",
            "res_model": "export.file.save",
            "views": [[False, "form"]],
            "res_id": sfs_id.id,
            "target": "new",
        }
