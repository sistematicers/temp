# -*- encoding: utf-8 -*-
{
    'name': 'PLE Caja Banco Sunat',
    'category': 'account',
    'author': 'PERUVIAN-COMPATIBLE-BO',
    'depends': ['import_base_pe', 'ple_diario_sunat_pe', 'l10n_pe_datas', 'account'],
    'version': '1.0',
    'description': """
    PLE Caja Banco
    """,
    'auto_install': False,
    'demo': [],
    'data': [
        'wizard/ple_cajabanco_view.xml',
        'views/account_view.xml',
        'security/ir.model.access.csv'
    ],
    'installable': True
}
